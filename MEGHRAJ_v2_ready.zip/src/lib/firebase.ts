import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, type User } from 'firebase/auth'
import { getFirestore, doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'

/** 👉 Admin ka Gmail (sirf ye account Admin Panel dekh sakta hai). */
export const ADMIN_EMAILS = ['meghrajkumarv@gmail.com', 'mkstoretera@gmail.com']

/**
 * 👉 Firebase config (SETUP_LOCKER.md ke step 7). Ye keys secret nahi hoti —
 * suraksha firestore.rules se aati hai.
 */
const firebaseConfig = {
  apiKey: 'AIzaSyAG4E6kG6hzq6i9t4dfoYRfWmvsc-CmXxA',
  authDomain: 'meghraj-site.firebaseapp.com',
  projectId: 'meghraj-site',
  storageBucket: 'meghraj-site.firebasestorage.app',
  messagingSenderId: '128907906178',
  appId: '1:128907906178:web:1d8c1eaa33a57a6548f89b',
}

export const isConfigured =
  !firebaseConfig.apiKey.startsWith('PASTE') && !firebaseConfig.projectId.startsWith('PASTE')

const app = isConfigured ? initializeApp(firebaseConfig) : null
export const auth = app ? getAuth(app) : null
export const db = app ? getFirestore(app) : null

/** Google login + Drive ke private app-folder ki permission, ek hi popup mein. */
export async function signInGoogle(): Promise<{ user: User; accessToken: string }> {
  if (!auth) throw new Error('Not configured')
  const provider = new GoogleAuthProvider()
  provider.addScope('https://www.googleapis.com/auth/drive.appdata')
  const result = await signInWithPopup(auth, provider)
  const accessToken = GoogleAuthProvider.credentialFromResult(result)?.accessToken || ''
  await registerUser(result.user)
  return { user: result.user, accessToken }
}

export const signOutUser = () => (auth ? signOut(auth) : Promise.resolve())

/** Admin panel ke liye sirf profile record: naam, email, kab joined, kab aakhri baar aaya. */
async function registerUser(u: User) {
  if (!db) return
  const ref = doc(db, 'users', u.uid)
  const snap = await getDoc(ref)
  const base = { name: u.displayName || '', email: u.email || '', photo: u.photoURL || '', lastSeen: serverTimestamp() }
  if (snap.exists()) await setDoc(ref, base, { merge: true })
  else await setDoc(ref, { ...base, firstSeen: serverTimestamp(), files: 0 })
}
