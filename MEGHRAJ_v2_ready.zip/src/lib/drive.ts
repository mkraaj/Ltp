/** Files user ke apne Google Drive ke chhupe hue "app data" folder mein jaati hain. */
const API = 'https://www.googleapis.com/drive/v3'
const q = (s: string) => encodeURIComponent(s)

let token = ''
let exp = 0
export const setDriveToken = (t: string) => { token = t; exp = Date.now() + 55 * 60 * 1000 }
export const hasDriveToken = () => !!token && Date.now() < exp
export const clearDriveToken = () => { token = ''; exp = 0 }

export interface DriveItem { id: string; pid: string; name: string; mime: string; size: number; created: string; thumbId?: string }

async function authFetch(url: string, init: RequestInit = {}): Promise<Response> {
  if (!hasDriveToken()) throw new Error('AUTH:expired')
  const res = await fetch(url, { ...init, headers: { ...(init.headers || {}), Authorization: `Bearer ${token}` } })
  if (res.status === 401) { clearDriveToken(); throw new Error('AUTH:expired') }
  if (!res.ok) {
    const j = await res.json().catch(() => null)
    throw new Error(j?.error?.message || `Google Drive error ${res.status}`)
  }
  return res
}

export async function listItems(pageToken?: string): Promise<{ items: DriveItem[]; next?: string }> {
  const query = "appProperties has { key='kind' and value='item' } and trashed=false"
  const url = `${API}/files?spaces=appDataFolder&pageSize=48&orderBy=createdTime%20desc&q=${q(query)}` +
    `&fields=${q('nextPageToken,files(id,name,mimeType,size,createdTime,appProperties)')}` + (pageToken ? `&pageToken=${q(pageToken)}` : '')
  const j = await (await authFetch(url)).json()
  return {
    items: (j.files || []).map((f: any) => ({
      id: f.id, pid: f.appProperties?.pid, name: f.name, mime: f.mimeType || '',
      size: Number(f.size || 0), created: f.createdTime, thumbId: f.appProperties?.thumb || undefined,
    })),
    next: j.nextPageToken,
  }
}

export async function getBlob(id: string): Promise<Blob> {
  return (await authFetch(`${API}/files/${id}?alt=media`)).blob()
}

async function upload(name: string, blob: Blob, appProperties: Record<string, string>): Promise<string> {
  const mime = blob.type || 'application/octet-stream'
  const meta = { name, parents: ['appDataFolder'], mimeType: mime, appProperties }
  const b = 'mlb' + Math.random().toString(36).slice(2)
  const body = new Blob([
    `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${b}\r\nContent-Type: ${mime}\r\n\r\n`,
    blob, `\r\n--${b}--`,
  ])
  const res = await authFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id', {
    method: 'POST', headers: { 'Content-Type': `multipart/related; boundary=${b}` }, body,
  })
  return (await res.json()).id as string
}

export async function saveItem(name: string, file: Blob, thumb?: Blob): Promise<void> {
  const pid = Date.now().toString(36) + Math.random().toString(36).slice(2, 7)
  const props: Record<string, string> = { kind: 'item', pid }
  if (thumb) props.thumb = await upload(name, thumb, { kind: 'thumb', pid })
  await upload(name, file, props)
}

export async function deleteItem(it: DriveItem): Promise<void> {
  await authFetch(`${API}/files/${it.id}`, { method: 'DELETE' })
  if (it.thumbId) await authFetch(`${API}/files/${it.thumbId}`, { method: 'DELETE' }).catch(() => {})
}
