import { useEffect, useMemo, useState } from 'react'
import { onAuthStateChanged, type User } from 'firebase/auth'
import { collection, getDocs, orderBy, query } from 'firebase/firestore'
import { auth, db, isConfigured, signInGoogle, signOutUser, ADMIN_EMAILS } from '@/lib/firebase'
import { download } from '@/lib/tools'

interface Row { uid: string; name: string; email: string; firstSeen?: Date; lastSeen?: Date; files: number }
const fmt = (d?: Date) => (d ? d.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—')

export function AdminPanel() {
  const [user, setUser] = useState<User | null>(null)
  const [ready, setReady] = useState(!isConfigured)
  const [rows, setRows] = useState<Row[]>([])
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => { if (auth) return onAuthStateChanged(auth, (u) => { setUser(u); setReady(true) }) }, [])
  const isAdmin = !!user && ADMIN_EMAILS.includes(user.email || '')

  useEffect(() => {
    if (!isAdmin || !db) return
    setBusy(true); setErr('')
    getDocs(query(collection(db, 'users'), orderBy('firstSeen', 'desc')))
      .then((snap) => setRows(snap.docs.map((d) => {
        const v = d.data()
        return { uid: d.id, name: v.name || '', email: v.email || '', firstSeen: v.firstSeen?.toDate?.(), lastSeen: v.lastSeen?.toDate?.(), files: Number(v.files || 0) }
      })))
      .catch((e) => setErr(e?.code === 'permission-denied' ? 'Permission denied. Publish firestore.rules in Firebase.' : e?.message || 'Could not load users.'))
      .finally(() => setBusy(false))
  }, [isAdmin])

  const login = async () => { setErr(''); try { await signInGoogle() } catch (e: any) { if (!String(e?.code).includes('popup')) setErr(e?.message || 'Sign-in failed.') } }

  const shown = useMemo(() => {
    const s = search.toLowerCase().trim()
    return s ? rows.filter((r) => r.name.toLowerCase().includes(s) || r.email.toLowerCase().includes(s)) : rows
  }, [rows, search])
  const now = Date.now()
  const today = rows.filter((r) => r.firstSeen && now - r.firstSeen.getTime() < 86400000).length
  const week = rows.filter((r) => r.firstSeen && now - r.firstSeen.getTime() < 7 * 86400000).length

  const exportCsv = () => {
    const esc = (v: string) => `"${v.replace(/"/g, '""')}"`
    const csv = ['Name,Email,Joined,Last seen,Files', ...shown.map((r) => [esc(r.name), esc(r.email), esc(fmt(r.firstSeen)), esc(fmt(r.lastSeen)), r.files].join(','))].join('\n')
    download(new Blob([csv], { type: 'text/csv' }), 'meghraj-users.csv')
  }

  const wrap = (children: React.ReactNode) => <div className="container mx-auto max-w-4xl px-4 py-10">{children}</div>

  if (!isConfigured) return wrap(<p className="text-center text-muted-foreground">Admin panel is not set up yet. Add the Firebase config first (SETUP_LOCKER.md).</p>)
  if (!ready) return wrap(<div className="py-10 text-center"><div className="w-10 h-10 mx-auto rounded-full border-4 border-primary/30 border-t-primary animate-spin" /></div>)

  if (!user) {
    return wrap(
      <div className="glass rounded-3xl p-8 text-center space-y-4 max-w-md mx-auto">
        <p className="text-4xl">🛡️</p>
        <h1 className="font-display text-2xl font-bold">Admin login</h1>
        <p className="text-sm text-muted-foreground">Sign in with the admin Google account.</p>
        <button onClick={login} className="px-6 py-3 rounded-2xl bg-white text-slate-800 font-semibold shadow-lg">Continue with Google</button>
        {err && <p className="text-sm text-red-500">{err}</p>}
      </div>
    )
  }
  if (!isAdmin) {
    return wrap(
      <div className="glass rounded-3xl p-8 text-center space-y-4 max-w-md mx-auto">
        <p className="text-4xl">🚫</p>
        <h1 className="font-display text-xl font-bold">This account is not an admin</h1>
        <p className="text-sm text-muted-foreground">{user.email}</p>
        <button onClick={() => signOutUser()} className="px-5 py-2.5 rounded-xl border border-border text-sm font-medium">Sign out</button>
      </div>
    )
  }

  return wrap(
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-bold">Admin panel</h1>
        <button onClick={() => signOutUser()} className="px-4 py-2 rounded-xl border border-border text-sm font-medium">Sign out</button>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[['Total users', rows.length], ['New today', today], ['Last 7 days', week]].map(([l, v]) => (
          <div key={l as string} className="glass rounded-2xl p-4 text-center"><p className="text-2xl font-display font-bold">{v}</p><p className="text-xs text-muted-foreground">{l}</p></div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">Users' files are stored in their own Google Drive. This panel shows only profile details and the number of files.</p>
      <div className="flex gap-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name or email" className="flex-1 px-4 py-3 rounded-xl border border-border bg-background text-sm" />
        <button onClick={exportCsv} className="px-4 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-medium">CSV</button>
      </div>
      {err && <p className="text-sm text-red-500">{err}</p>}
      {busy && <p className="text-sm text-muted-foreground text-center">Loading…</p>}
      <div className="space-y-2">
        {shown.map((r) => (
          <div key={r.uid} className="glass rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-2">
            <div className="min-w-0"><p className="font-medium truncate">{r.name || 'No name'}</p><p className="text-xs text-muted-foreground truncate">{r.email}</p></div>
            <div className="text-right text-xs text-muted-foreground"><p>Joined {fmt(r.firstSeen)}</p><p>Last seen {fmt(r.lastSeen)} • {r.files} files</p></div>
          </div>
        ))}
        {!busy && shown.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No users yet.</p>}
      </div>
    </div>
  )
}
