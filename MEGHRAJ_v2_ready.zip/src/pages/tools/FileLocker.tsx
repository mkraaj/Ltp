import { useCallback, useEffect, useState } from 'react'
import { onAuthStateChanged, type User } from 'firebase/auth'
import { doc, increment, setDoc } from 'firebase/firestore'
import { ToolShell, ErrorBox } from '@/components/ToolShell'
import { UploadZone, ProgressBar } from '@/components/UploadZone'
import { TOOLS, fmtSize, download } from '@/lib/tools'
import { loadImage, drawToCanvas, canvasToBlob } from '@/lib/imaging'
import { auth, db, isConfigured, signInGoogle, signOutUser } from '@/lib/firebase'
import { setDriveToken, hasDriveToken, clearDriveToken, listItems, getBlob, saveItem, deleteItem, type DriveItem } from '@/lib/drive'

const tool = TOOLS.find((t) => t.id === 'file-locker')!
const MAX_MB = 25
const THUMB_SIDE = 320

interface Tile extends DriveItem { url?: string }

const extOf = (n: string) => (n.split('.').pop() || 'file').slice(0, 4).toUpperCase()
const isImg = (m: string) => m.startsWith('image/')

function friendlyError(e: any): string {
  const c = e?.code || '', m: string = e?.message || ''
  if (c === 'auth/popup-closed-by-user' || c === 'auth/cancelled-popup-request') return ''
  if (c === 'auth/popup-blocked') return 'Popup blocked by your browser. Allow popups for this site and try again.'
  if (c === 'auth/unauthorized-domain') return 'This website address is not added in Firebase → Authentication → Authorized domains.'
  if (c === 'permission-denied') return 'Permission denied. Check that firestore.rules is published in Firebase.'
  if (m.startsWith('AUTH:')) return 'Please unlock your files again with Google.'
  if (m.includes('Failed to fetch')) return 'No internet connection. Please try again.'
  return m || 'Something went wrong. Please try again.'
}
const isAuthErr = (e: any) => String(e?.message || '').startsWith('AUTH:')

export function FileLocker() {
  const [user, setUser] = useState<User | null>(null)
  const [ready, setReady] = useState(!isConfigured)
  const [unlocked, setUnlocked] = useState(hasDriveToken())
  const [items, setItems] = useState<Tile[]>([])
  const [next, setNext] = useState<string | undefined>()
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const [prog, setProg] = useState(0)
  const [status, setStatus] = useState('')
  const [open, setOpen] = useState<{ it: Tile; url?: string } | null>(null)
  const [opening, setOpening] = useState(false)

  useEffect(() => {
    if (!auth) return
    return onAuthStateChanged(auth, (u) => { setUser(u); setReady(true) })
  }, [])

  const handle = (e: any) => {
    if (isAuthErr(e)) setUnlocked(false)
    setErr(friendlyError(e))
  }

  const bump = async (n: number) => {
    if (!db || !user) return
    try { await setDoc(doc(db, 'users', user.uid), { files: increment(n) }, { merge: true }) } catch { /* admin count only */ }
  }

  const load = useCallback(async (page?: string) => {
    setLoading(true); setErr('')
    try {
      const { items: list, next: n } = await listItems(page)
      const tiles: Tile[] = []
      for (let i = 0; i < list.length; i += 6) {
        tiles.push(...await Promise.all(list.slice(i, i + 6).map(async (t): Promise<Tile> => {
          if (!t.thumbId) return t
          try { return { ...t, url: URL.createObjectURL(await getBlob(t.thumbId)) } } catch { return t }
        })))
      }
      setItems((prev) => (page ? [...prev, ...tiles] : tiles))
      setNext(n)
    } catch (e: any) { handle(e) }
    setLoading(false)
  }, [])

  const unlock = async () => {
    setErr('')
    try {
      const { accessToken } = await signInGoogle()
      if (!accessToken) throw new Error('Google Drive permission was not given. Please allow it and try again.')
      setDriveToken(accessToken); setUnlocked(true); load()
    } catch (e: any) { handle(e) }
  }

  const logout = async () => {
    clearDriveToken(); setUnlocked(false); setItems([]); setNext(undefined)
    await signOutUser()
  }

  const upload = async (files: File[]) => {
    setErr(''); setProg(1)
    let done = 0, saved = 0
    const failed: string[] = []
    for (const file of files) {
      setStatus(`Saving ${done + 1}/${files.length}: ${file.name}`)
      try {
        let thumb: Blob | undefined
        if (isImg(file.type)) {
          try {
            const img = await loadImage(file)
            const s = Math.min(1, THUMB_SIDE / Math.max(img.naturalWidth, img.naturalHeight))
            thumb = await canvasToBlob(drawToCanvas(img, img.naturalWidth * s, img.naturalHeight * s), 'image/jpeg', 0.7)
          } catch { /* thumbnail optional */ }
        }
        await saveItem(file.name, file, thumb)
        saved++
      } catch (e: any) {
        if (isAuthErr(e)) { handle(e); break }
        failed.push(file.name)
      }
      done++
      setProg((done / files.length) * 100)
    }
    setProg(0); setStatus('')
    if (failed.length) setErr(`Could not save: ${failed.join(', ')}`)
    if (saved) await bump(saved)
    await load()
  }

  const view = async (t: Tile) => {
    setOpen({ it: t }); setOpening(true); setErr('')
    try {
      if (isImg(t.mime)) setOpen({ it: t, url: URL.createObjectURL(await getBlob(t.id)) })
    } catch (e: any) { handle(e); setOpen(null) }
    setOpening(false)
  }

  const save = async () => {
    if (!open) return
    try { download(await getBlob(open.it.id), open.it.name) } catch (e: any) { handle(e) }
  }

  const remove = async () => {
    if (!open || !window.confirm('Delete this file permanently?')) return
    try {
      await deleteItem(open.it)
      setItems((prev) => prev.filter((x) => x.id !== open.it.id))
      setOpen(null); await bump(-1)
    } catch (e: any) { handle(e) }
  }

  if (!isConfigured) {
    return (
      <ToolShell tool={tool}>
        <div className="text-center py-6 space-y-3">
          <p className="text-4xl">🛠️</p>
          <p className="font-display font-semibold text-lg">File Locker is not set up yet</p>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">Add your Firebase config in <code className="font-mono">src/lib/firebase.ts</code>. Steps are in <code className="font-mono">SETUP_LOCKER.md</code>.</p>
        </div>
      </ToolShell>
    )
  }
  if (!ready) {
    return <ToolShell tool={tool}><div className="py-10 text-center"><div className="w-10 h-10 mx-auto rounded-full border-4 border-primary/30 border-t-primary animate-spin" /></div></ToolShell>
  }

  const googleBtn = (label: string) => (
    <button onClick={unlock} className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-white text-slate-800 font-semibold shadow-lg hover:shadow-xl active:scale-95 transition-all">
      <svg width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z"/></svg>
      {label}
    </button>
  )

  if (!user || !unlocked) {
    return (
      <ToolShell tool={tool}>
        <div className="text-center py-8 space-y-5">
          <p className="text-5xl">🔐</p>
          <div>
            <p className="font-display font-semibold text-xl">{user ? 'Unlock your files' : 'Your private file locker'}</p>
            <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
              {user ? `Signed in as ${user.email}. Tap below to open your saved files.` : 'Sign in with Google to save documents and photos to your account. Open them anytime from any phone or computer using the same Gmail.'}
            </p>
          </div>
          {googleBtn(user ? 'Unlock with Google' : 'Continue with Google')}
          <p className="text-xs text-muted-foreground max-w-md mx-auto">Your files are stored in a hidden private folder of your own Google Drive. MEGHRAJ keeps only your name, email and join date so you can sign in.</p>
          <ErrorBox msg={err} />
        </div>
      </ToolShell>
    )
  }

  return (
    <ToolShell tool={tool}>
      <div className="space-y-6">
        <div className="flex items-center gap-3 glass rounded-2xl px-4 py-3">
          {user.photoURL ? <img src={user.photoURL} alt="" referrerPolicy="no-referrer" className="w-10 h-10 rounded-full" /> : <span className="w-10 h-10 rounded-full bg-primary/20 grid place-items-center">👤</span>}
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium truncate">{user.displayName || 'Signed in'}</p>
            <p className="text-xs text-muted-foreground truncate">{user.email}</p>
          </div>
          <button onClick={logout} className="px-3.5 py-2 rounded-xl border border-border hover:bg-accent text-sm font-medium">Sign out</button>
        </div>

        <UploadZone multiple maxSizeMB={MAX_MB} onFiles={upload}
          label="Add documents or photos"
          sublabel={`Any file up to ${MAX_MB} MB • saved in your own Google Drive`} />
        {prog > 0 && <ProgressBar value={prog} label={status} />}
        <ErrorBox msg={err} />

        <div>
          <p className="font-display font-semibold mb-3">Your files {items.length > 0 && <span className="text-muted-foreground font-normal text-sm">({items.length}{next ? '+' : ''})</span>}</p>
          {items.length === 0 && !loading && <p className="text-sm text-muted-foreground text-center py-8">Nothing saved yet. Add your first file above.</p>}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {items.map((t) => (
              <button key={t.id} onClick={() => view(t)} className="group relative aspect-square overflow-hidden rounded-2xl glass hover:shadow-xl transition-all">
                {t.url
                  ? <img src={t.url} alt={t.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  : <span className="w-full h-full grid place-items-center text-2xl font-display font-bold text-primary">{extOf(t.name)}</span>}
                <span className="absolute inset-x-0 bottom-0 bg-black/55 text-white text-[11px] px-2 py-1 truncate">{t.name}</span>
              </button>
            ))}
          </div>
          {loading && <div className="py-6 text-center"><div className="w-8 h-8 mx-auto rounded-full border-4 border-primary/30 border-t-primary animate-spin" /></div>}
          {next && !loading && <button onClick={() => load(next)} className="mt-4 w-full py-3 rounded-xl border border-border hover:bg-accent text-sm font-medium">Load more</button>}
        </div>
      </div>

      {open && (
        <div className="fixed inset-0 z-[100] bg-black/85 grid place-items-center p-4" onClick={() => !opening && setOpen(null)}>
          <div className="max-w-3xl w-full text-center" onClick={(e) => e.stopPropagation()}>
            {opening ? <div className="w-10 h-10 mx-auto rounded-full border-4 border-white/30 border-t-white animate-spin" /> : (
              <>
                {open.url
                  ? <img src={open.url} alt={open.it.name} className="max-h-[65vh] w-auto mx-auto rounded-2xl" />
                  : <div className="glass rounded-2xl py-10 px-4"><p className="text-3xl font-display font-bold text-primary">{extOf(open.it.name)}</p><p className="mt-2 text-sm break-all">{open.it.name}</p><p className="text-xs text-muted-foreground">{fmtSize(open.it.size)}</p></div>}
                <div className="mt-4 flex flex-wrap gap-2 justify-center">
                  <button onClick={save} className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium">⬇️ Download</button>
                  <button onClick={remove} className="px-4 py-2.5 rounded-xl bg-red-500 text-white text-sm font-medium">🗑️ Delete</button>
                  <button onClick={() => setOpen(null)} className="px-4 py-2.5 rounded-xl bg-white/15 text-white text-sm font-medium">Close</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </ToolShell>
  )
}
