# File Locker + Admin panel — setup (sirf 1 baar)

Kya milega:
- Users **Google se login** karke documents/photos upload karte hain. Files unke **apne Google Drive ke chhupe private folder** mein jaati hain, aur usi Gmail se kisi bhi device par wapas mil jaati hain.
- Aap (**meghrajkumarv@gmail.com** ya **mkstoretera@gmail.com**) `https://mkraaj.github.io/Ltp/#/admin` par Admin login karke dekhte ho: kitne naye users aaye, naam, email, kab joined, kab aakhri baar aaye, kitni files.
- Users ki files aapko nahi dikhti (wo unke Drive mein hain) — ye site ki Privacy page par likha hai.
- Koi card/payment nahi chahiye (Firebase free Spark plan).

Chrome mein "Desktop site" on kar lena. Menu ke naam thode alag ho sakte hain.

1. https://console.firebase.google.com → **Add project** → naam `meghraj-site` → Google Analytics **off** → Create.
2. **Build → Authentication → Get started → Sign-in method → Google → Enable** → support email chuno → Save.
3. **Authentication → Settings → Authorized domains → Add domain**: `mkraaj.github.io`
4. **Build → Firestore Database → Create database** → location `asia-south1 (Mumbai)` → **Production mode** → Create.
5. Firestore → **Rules** tab → purana text hata kar `firestore.rules` file ka poora text paste karo → **Publish**.
6. https://console.cloud.google.com kholo, upar wahi project `meghraj-site` chuno → **APIs & Services → Library → Google Drive API → Enable**.
7. Firebase **Project settings (gear) → Your apps → Web (`</>`)** → app naam `meghraj-web` → Register → jo `firebaseConfig` dikhe use copy karke mujhe bhej do (ye config secret nahi hoti). Main use `src/lib/firebase.ts` mein daal kar nayi zip bana dunga.

## Dhyan rakho
- Admin panel sirf `meghrajkumarv@gmail.com` se khulta hai; ye rules se bhi lock hai.
- File limit 25 MB prati file. Drive ke 15 GB mein user ki apni jagah use hoti hai.
- Har session mein "Unlock with Google" ek baar dabana padta hai (Google ka token 1 ghante ka hota hai).
